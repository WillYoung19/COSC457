package GUIHome;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Container;
import java.awt.Image;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Gui {

	private JFrame frame;
	private JLayeredPane layeredPane;
	private JPanel pnlHome;
	private JPanel pnlEmployee;
	private JPanel pnlTables;
	private JPanel pnlTickets;
	private JButton btnHome;
	private JButton btnHome_1;
	private JButton btnHome_3;
	private JTextField txtField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JPanel pnlTable1;
	private Container layeredPane_1;
	private JLayeredPane layeredPane_2;
	private JPanel pnlTble1E;
	private JPanel pnlTbl1F;
	private JButton btnNewButton_1;
	private JLayeredPane layeredPane_3;
	private JPanel pnlTbl2E;
	private JButton btnNewButton_2;
	private JPanel pnlTbl2F;
	private JButton btnNewButton_3;
	private JLayeredPane layeredPane_4;
	private JPanel pnlTbl3E;
	private JButton btnNewButton_4;
	private JPanel pnlTbl3F;
	private JButton btnNewButton_5;
	private JLayeredPane layeredPane_5;
	private JPanel pnlTbl4E;
	private JButton btnNewButton_6;
	private JPanel pnlTbl4F;
	private JButton btnNewButton_7;
	private JLabel lblNewLabel_4_3;
	private JLayeredPane layeredPane_6;
	private JPanel pnlTbl5E;
	private JButton btnNewButton_8;
	private JPanel pnlTbl5F;
	private JButton btnNewButton_9;
	private JLabel lblNewLabel_4_4;
	private JLayeredPane layeredPane_7;
	private JPanel pnlTbl6E;
	private JButton btnNewButton_10;
	private JPanel pnlTbl6F;
	private JButton btnNewButton_11;
	private JLayeredPane layeredPane_8;
	private JPanel pnlTbl7E;
	private JButton btnNewButton_12;
	private JPanel pnlTbl7F;
	private JButton btnNewButton_13;
	private JLayeredPane layeredPane_9;
	private JPanel pnlTbl8E;
	private JButton btnNewButton_14;
	private JPanel pnlTbl8F;
	private JButton btnNewButton_15;
	private JLayeredPane layeredPane_10;
	private JPanel pnlTbl9E;
	private JButton btnNewButton_16;
	private JPanel pnlTbl9F;
	private JButton btnNewButton_17;
	private JLayeredPane layeredPane_11;
	private JPanel pnlTbl10E;
	private JButton btnNewButton_18;
	private JPanel pnlTbl10F;
	private JButton btnNewButton_19;
	private JLayeredPane layeredPane_12;
	private JPanel pnlTbl11E;
	private JButton btnNewButton_20;
	private JPanel pnlTbl11F;
	private JButton btnNewButton_21;
	private JLayeredPane layeredPane_13;
	private JPanel pnlTbl12E;
	private JButton btnNewButton_22;
	private JPanel pnlTbl12F;
	private JButton btnNewButton_23;
	private JLayeredPane layeredPane_14;
	private JPanel pnlTbl13E;
	private JButton btnNewButton_24;
	private JPanel pnlTbl13F;
	private JButton btnNewButton_25;
	private JLayeredPane layeredPane_15;
	private JPanel pnlTbl14E;
	private JButton btnNewButton_26;
	private JPanel pnlTbl14F;
	private JButton btnNewButton_27;
	private JLayeredPane layeredPane_16;
	private JPanel pnlTbl15E;
	private JButton btnNewButton_28;
	private JPanel pnlTbl15F;
	private JButton btnNewButton_29;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_4_5;
	private JLabel lblNewLabel_4_6;
	private JLabel lblNewLabel_4_7;
	private JLabel lblNewLabel_4_8;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_4_9;
	private JLabel lblNewLabel_4_10;
	private JLabel lblNewLabel_4_11;
	private JLabel lblNewLabel_4_12;
	private Container layeredPaneTkt;
	private JPanel pnlCreTkt;
	private JPanel pnlActTkt;
	private JPanel pnlCldTkt;
	private JLabel lblTicket;
	private JLabel lblTableNum;
	private JLabel lblOrderId;
	private JLabel lblTicket_2;
	private JLabel lblTicketTotal;
	private JTextField textField;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JButton btnNewButton_31;
	private JButton btnNewButton_32;
	private JButton btnNewButton_33;
	private JLabel lblActive;
	private JButton btnNewButton_34;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JPanel pnlVewOrd;
	private JPanel pnlCrtOrd;
	private JLabel lblOrderId_1;
	private JLabel lblFoodId_1;
	private JLabel lblDrinkId_1;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JLabel lblCreateOrder;
	private JButton btnNewButton_35;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui window = new Gui();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Gui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
	frame = new JFrame();
	frame.setBounds(100, 100, 810, 499);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.getContentPane().setLayout(null);

	layeredPane = new JLayeredPane();
	layeredPane.setBounds(0, 0, 794, 460);
	frame.getContentPane().add(layeredPane);
					
						
							pnlHome = new JPanel();
							pnlHome.setBackground(Color.GRAY);
							pnlHome.setForeground(Color.WHITE);
							pnlHome.setBounds(0, 0, 794, 460);
							layeredPane.add(pnlHome);
							
								JButton btnEmployee = new JButton("Employee");
								btnEmployee.setBounds(160, 23, 103, 36);
								btnEmployee.setFont(new Font("Times New Roman", Font.BOLD, 14));
								btnEmployee.setForeground(new Color(153, 0, 51));
								btnEmployee.setBackground(new Color(255, 255, 204));
								btnEmployee.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
								Switch_Screen(pnlEmployee);
								}
								});
								pnlHome.setLayout(null);
								pnlHome.add(btnEmployee);
								
									JButton btnTables = new JButton("Tables");
									btnTables.setBounds(345, 23, 103, 36);
									btnTables.setFont(new Font("Times New Roman", Font.BOLD, 14));
									btnTables.setForeground(new Color(153, 0, 51));
									btnTables.setBackground(new Color(255, 255, 204));
									btnTables.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
									Switch_Screen(pnlTables);
									}
									});
									pnlHome.add(btnTables);
									
										JButton btnTickets = new JButton("Tickets");
										btnTickets.setBounds(530, 23, 103, 36);
										btnTickets.setForeground(new Color(153, 0, 51));
										btnTickets.setFont(new Font("Times New Roman", Font.BOLD, 14));
										btnTickets.setBackground(new Color(255, 255, 204));
										btnTickets.addActionListener(new ActionListener() {
										public void actionPerformed(ActionEvent e) {
										Switch_Screen(pnlTickets);
										}
										});
										pnlHome.add(btnTickets);
										
											JButton btnLogOut = new JButton("LogOut");
											btnLogOut.setBounds(10, 413, 103, 36);
											btnLogOut.setBackground(new Color(255, 255, 204));
											btnLogOut.setFont(new Font("Times New Roman", Font.BOLD, 14));
											btnLogOut.setForeground(new Color(153, 0, 51));
											btnLogOut.addActionListener(new ActionListener() {
											public void actionPerformed(ActionEvent e) {
											frame.dispose();
											}
											});
											pnlHome.add(btnLogOut);
											
											JLabel lblNewLabel_7 = new JLabel("");
											Image img = new ImageIcon (this.getClass().getResource("/MatsuriImg.png")).getImage();
											lblNewLabel_7.setIcon(new ImageIcon(img));
											lblNewLabel_7.setBounds(160, 79, 473, 328);
											pnlHome.add(lblNewLabel_7);
					
					
					
					
						pnlEmployee = new JPanel();
						pnlEmployee.setBackground(Color.GRAY);
						pnlEmployee.setBounds(0, 0, 794, 460);
						layeredPane.add(pnlEmployee);
						pnlEmployee.setLayout(null);
						
							btnHome = new JButton("Home");
							btnHome.setForeground(new Color(153, 0, 51));
							btnHome.setFont(new Font("Times New Roman", Font.BOLD, 14));
							btnHome.setBackground(new Color(255, 255, 204));
							btnHome.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
							Switch_Screen(pnlHome);
							}
							});
							btnHome.setBounds(696, 11, 88, 31);
							pnlEmployee.add(btnHome);
							
								JLabel lblHireDate = new JLabel("Employee ID:");
								lblHireDate.setForeground(new Color(255, 255, 204));
								lblHireDate.setFont(new Font("Tahoma", Font.BOLD, 18));
								lblHireDate.setBounds(178, 100, 122, 43);
								pnlEmployee.add(lblHireDate);
								
									JLabel lblWage = new JLabel("Name:");
									lblWage.setBackground(new Color(255, 255, 255));
									lblWage.setForeground(new Color(255, 255, 204));
									lblWage.setFont(new Font("Tahoma", Font.BOLD, 18));
									lblWage.setBounds(178, 167, 97, 43);
									pnlEmployee.add(lblWage);
									
										JLabel lblName = new JLabel("Age:");
										lblName.setForeground(new Color(255, 255, 204));
										lblName.setFont(new Font("Tahoma", Font.BOLD, 18));
										lblName.setBounds(178, 234, 97, 43);
										pnlEmployee.add(lblName);
										
											JLabel lblAge = new JLabel("Wage:");
											lblAge.setForeground(new Color(255, 255, 204));
											lblAge.setFont(new Font("Tahoma", Font.BOLD, 18));
											lblAge.setBounds(178, 301, 97, 43);
											pnlEmployee.add(lblAge);
											
												JLabel lblEmployeeID = new JLabel("Hire Date:");
												lblEmployeeID.setForeground(new Color(255, 255, 204));
												lblEmployeeID.setFont(new Font("Tahoma", Font.BOLD, 18));
												lblEmployeeID.setBounds(178, 368, 122, 43);
												pnlEmployee.add(lblEmployeeID);
												
													JSeparator separator = new JSeparator();
													separator.setBounds(31, 355, 734, 2);
													pnlEmployee.add(separator);
													
														JSeparator separator_1 = new JSeparator();
														separator_1.setBounds(31, 288, 734, 2);
														pnlEmployee.add(separator_1);
														
															JSeparator separator_2 = new JSeparator();
															separator_2.setBounds(31, 221, 734, 2);
															pnlEmployee.add(separator_2);
															
																JSeparator separator_3 = new JSeparator();
																separator_3.setBounds(31, 154, 734, 2);
																pnlEmployee.add(separator_3);
																
																	txtField = new JTextField();
																	txtField.setEditable(false);
																	txtField.setHorizontalAlignment(SwingConstants.CENTER);
																	txtField.setForeground(new Color(153, 0, 51));
																	txtField.setBounds(361, 107, 177, 34);
																	pnlEmployee.add(txtField);
																	txtField.setColumns(10);
																	
																		textField_1 = new JTextField();
																		textField_1.setEditable(false);
																		textField_1.setForeground(new Color(153, 0, 51));
																		textField_1.setColumns(10);
																		textField_1.setBounds(361, 174, 177, 34);
																		pnlEmployee.add(textField_1);
																		
																			textField_2 = new JTextField();
																			textField_2.setEditable(false);
																			textField_2.setForeground(new Color(153, 0, 51));
																			textField_2.setColumns(10);
																			textField_2.setBounds(361, 241, 177, 34);
																			pnlEmployee.add(textField_2);
																			
																				textField_3 = new JTextField();
																				textField_3.setEditable(false);
																				textField_3.setForeground(new Color(153, 0, 51));
																				textField_3.setColumns(10);
																				textField_3.setBounds(361, 308, 177, 34);
																				pnlEmployee.add(textField_3);
																				
																					textField_4 = new JTextField();
																					textField_4.setEditable(false);
																					textField_4.setForeground(new Color(153, 0, 51));
																					textField_4.setColumns(10);
																					textField_4.setBounds(361, 375, 177, 34);
																					pnlEmployee.add(textField_4);
																					
																						lblNewLabel_2 = new JLabel("Employee");
																						lblNewLabel_2.setForeground(new Color(255, 255, 204));
																						lblNewLabel_2.setFont(new Font("Lucida Handwriting", Font.BOLD, 32));
																						lblNewLabel_2.setBounds(316, 11, 183, 48);
																						pnlEmployee.add(lblNewLabel_2);
																						

	pnlTables = new JPanel();
	pnlTables.setBackground(Color.GRAY);
	pnlTables.setBounds(0, 0, 794, 460);
	layeredPane.add(pnlTables);
	
	
		btnHome_1 = new JButton("Home");
		btnHome_1.setBounds(696, 11, 88, 31);
		btnHome_1.setBackground(new Color(255, 255, 204));
		btnHome_1.setForeground(new Color(153, 0, 51));
		btnHome_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnHome_1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		Switch_Screen(pnlHome);
		}
		});
		pnlTables.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Table 1");
		lblNewLabel_4.setForeground(new Color(255, 250, 205));
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_4.setBounds(67, 69, 76, 14);
		pnlTables.add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("Table 2");
		lblNewLabel_4_1.setForeground(new Color(255, 250, 205));
		lblNewLabel_4_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_4_1.setBounds(210, 69, 76, 14);
		pnlTables.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4_2 = new JLabel("Table 3");
		lblNewLabel_4_2.setForeground(new Color(255, 250, 205));
		lblNewLabel_4_2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_4_2.setBounds(362, 69, 76, 14);
		pnlTables.add(lblNewLabel_4_2);
		
		lblNewLabel_4_3 = new JLabel("Table 4");
		lblNewLabel_4_3.setForeground(new Color(255, 250, 205));
		lblNewLabel_4_3.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_4_3.setBounds(500, 69, 76, 14);
		pnlTables.add(lblNewLabel_4_3);
		
		lblNewLabel_4_4 = new JLabel("Table 5");
		lblNewLabel_4_4.setForeground(new Color(255, 250, 205));
		lblNewLabel_4_4.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_4_4.setBounds(639, 69, 76, 14);
		pnlTables.add(lblNewLabel_4_4);
		pnlTables.add(btnHome_1);
		
			lblNewLabel_3 = new JLabel("Tables");
			lblNewLabel_3.setBounds(327, 23, 140, 41);
			lblNewLabel_3.setForeground(new Color(255, 255, 204));
			lblNewLabel_3.setFont(new Font("Lucida Handwriting", Font.BOLD, 32));
			pnlTables.add(lblNewLabel_3);
			
			layeredPane_2 = new JLayeredPane();
			layeredPane_2.setBounds(57, 85, 76, 61);
			pnlTables.add(layeredPane_2);
			
			pnlTble1E = new JPanel();
			pnlTble1E.setBackground(Color.GREEN);
			pnlTble1E.setBounds(0, 0, 76, 61);
			layeredPane_2.add(pnlTble1E);
			
			JButton btnNewButton = new JButton("Empty");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table1(pnlTbl1F);
				}
			});
			pnlTble1E.add(btnNewButton);
			
			pnlTbl1F = new JPanel();
			pnlTbl1F.setBackground(Color.RED);
			pnlTbl1F.setBounds(0, 0, 76, 61);
			layeredPane_2.add(pnlTbl1F);
			
			btnNewButton_1 = new JButton("Full");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table1(pnlTble1E);
				}
			});
			pnlTbl1F.add(btnNewButton_1);
			
			layeredPane_3 = new JLayeredPane();
			layeredPane_3.setBounds(200, 85, 76, 61);
			pnlTables.add(layeredPane_3);
			
			pnlTbl2E = new JPanel();
			pnlTbl2E.setBackground(Color.GREEN);
			pnlTbl2E.setBounds(0, 0, 76, 61);
			layeredPane_3.add(pnlTbl2E);
			
			btnNewButton_2 = new JButton("Empty");
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table2(pnlTbl2F);
				}
			});
			pnlTbl2E.add(btnNewButton_2);
			
			pnlTbl2F = new JPanel();
			pnlTbl2F.setBackground(Color.RED);
			pnlTbl2F.setBounds(0, 0, 76, 61);
			layeredPane_3.add(pnlTbl2F);
			
			btnNewButton_3 = new JButton("Full");
			btnNewButton_3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table2(pnlTbl2E);
				}
			});
			pnlTbl2F.add(btnNewButton_3);
			
			layeredPane_4 = new JLayeredPane();
			layeredPane_4.setBounds(350, 85, 76, 61);
			pnlTables.add(layeredPane_4);
			
			pnlTbl3E = new JPanel();
			pnlTbl3E.setBackground(Color.GREEN);
			pnlTbl3E.setBounds(0, 0, 76, 61);
			layeredPane_4.add(pnlTbl3E);
			
			btnNewButton_4 = new JButton("Empty");
			btnNewButton_4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table3(pnlTbl3F);
				}
			});
			pnlTbl3E.add(btnNewButton_4);
			
			pnlTbl3F = new JPanel();
			pnlTbl3F.setBackground(Color.RED);
			pnlTbl3F.setBounds(0, 0, 76, 61);
			layeredPane_4.add(pnlTbl3F);
			
			btnNewButton_5 = new JButton("Full");
			btnNewButton_5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table3(pnlTbl3E);
				}
			});
			pnlTbl3F.add(btnNewButton_5);
			
			layeredPane_5 = new JLayeredPane();
			layeredPane_5.setBounds(490, 85, 76, 61);
			pnlTables.add(layeredPane_5);
			
			pnlTbl4E = new JPanel();
			pnlTbl4E.setBackground(Color.GREEN);
			pnlTbl4E.setBounds(0, 0, 76, 61);
			layeredPane_5.add(pnlTbl4E);
			
			btnNewButton_6 = new JButton("Empty");
			btnNewButton_6.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table4(pnlTbl4F);
				}
			});
			pnlTbl4E.add(btnNewButton_6);
			
			pnlTbl4F = new JPanel();
			pnlTbl4F.setBackground(Color.RED);
			pnlTbl4F.setBounds(0, 0, 76, 61);
			layeredPane_5.add(pnlTbl4F);
			
			btnNewButton_7 = new JButton("Full");
			btnNewButton_7.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table4(pnlTbl4E);
				}
			});
			pnlTbl4F.add(btnNewButton_7);
			
			layeredPane_6 = new JLayeredPane();
			layeredPane_6.setBounds(635, 85, 76, 61);
			pnlTables.add(layeredPane_6);
			
			pnlTbl5E = new JPanel();
			pnlTbl5E.setBackground(Color.GREEN);
			pnlTbl5E.setBounds(0, 0, 76, 61);
			layeredPane_6.add(pnlTbl5E);
			
			btnNewButton_8 = new JButton("Empty");
			btnNewButton_8.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table5(pnlTbl5F);
				}
			});
			pnlTbl5E.add(btnNewButton_8);
			
			pnlTbl5F = new JPanel();
			pnlTbl5F.setBackground(Color.RED);
			pnlTbl5F.setBounds(0, 0, 76, 61);
			layeredPane_6.add(pnlTbl5F);
			
			btnNewButton_9 = new JButton("Full");
			btnNewButton_9.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table5(pnlTbl5E);
				}
			});
			pnlTbl5F.add(btnNewButton_9);
			
			layeredPane_7 = new JLayeredPane();
			layeredPane_7.setBounds(57, 207, 76, 61);
			pnlTables.add(layeredPane_7);
			
			pnlTbl6E = new JPanel();
			pnlTbl6E.setBackground(Color.GREEN);
			pnlTbl6E.setBounds(0, 0, 76, 61);
			layeredPane_7.add(pnlTbl6E);
			
			btnNewButton_10 = new JButton("Empty");
			btnNewButton_10.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table6(pnlTbl6F);
				}
			});
			pnlTbl6E.add(btnNewButton_10);
			
			pnlTbl6F = new JPanel();
			pnlTbl6F.setBackground(Color.RED);
			pnlTbl6F.setBounds(0, 0, 76, 61);
			layeredPane_7.add(pnlTbl6F);
			
			btnNewButton_11 = new JButton("Full");
			btnNewButton_11.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table6(pnlTbl6E);
				}
			});
			pnlTbl6F.add(btnNewButton_11);
			
			layeredPane_8 = new JLayeredPane();
			layeredPane_8.setBounds(200, 207, 76, 61);
			pnlTables.add(layeredPane_8);
			
			pnlTbl7E = new JPanel();
			pnlTbl7E.setBackground(Color.GREEN);
			pnlTbl7E.setBounds(0, 0, 76, 61);
			layeredPane_8.add(pnlTbl7E);
			
			btnNewButton_12 = new JButton("Empty");
			btnNewButton_12.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table7(pnlTbl7F);
				}
			});
			pnlTbl7E.add(btnNewButton_12);
			
			pnlTbl7F = new JPanel();
			pnlTbl7F.setBackground(Color.RED);
			pnlTbl7F.setBounds(0, 0, 76, 61);
			layeredPane_8.add(pnlTbl7F);
			
			btnNewButton_13 = new JButton("Full");
			btnNewButton_13.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table7(pnlTbl7E);
				}
			});
			pnlTbl7F.add(btnNewButton_13);
			
			layeredPane_9 = new JLayeredPane();
			layeredPane_9.setBounds(350, 207, 76, 61);
			pnlTables.add(layeredPane_9);
			
			pnlTbl8E = new JPanel();
			pnlTbl8E.setBackground(Color.GREEN);
			pnlTbl8E.setBounds(0, 0, 76, 61);
			layeredPane_9.add(pnlTbl8E);
			
			btnNewButton_14 = new JButton("Empty");
			btnNewButton_14.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table8(pnlTbl8F);
				}
			});
			pnlTbl8E.add(btnNewButton_14);
			
			pnlTbl8F = new JPanel();
			pnlTbl8F.setBackground(Color.RED);
			pnlTbl8F.setBounds(0, 0, 76, 61);
			layeredPane_9.add(pnlTbl8F);
			
			btnNewButton_15 = new JButton("Full");
			btnNewButton_15.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table8(pnlTbl8E);
				}
			});
			pnlTbl8F.add(btnNewButton_15);
			
			layeredPane_10 = new JLayeredPane();
			layeredPane_10.setBounds(490, 207, 76, 61);
			pnlTables.add(layeredPane_10);
			
			pnlTbl9E = new JPanel();
			pnlTbl9E.setBackground(Color.GREEN);
			pnlTbl9E.setBounds(0, 0, 76, 61);
			layeredPane_10.add(pnlTbl9E);
			
			btnNewButton_16 = new JButton("Empty");
			btnNewButton_16.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table9(pnlTbl9F);
				}
			});
			pnlTbl9E.add(btnNewButton_16);
			
			pnlTbl9F = new JPanel();
			pnlTbl9F.setBackground(Color.RED);
			pnlTbl9F.setBounds(0, 0, 76, 61);
			layeredPane_10.add(pnlTbl9F);
			
			btnNewButton_17 = new JButton("Full");
			btnNewButton_17.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table9(pnlTbl9E);
				}
			});
			pnlTbl9F.add(btnNewButton_17);
			
			layeredPane_11 = new JLayeredPane();
			layeredPane_11.setBounds(635, 207, 76, 61);
			pnlTables.add(layeredPane_11);
			
			pnlTbl10E = new JPanel();
			pnlTbl10E.setBackground(Color.GREEN);
			pnlTbl10E.setBounds(0, 0, 76, 61);
			layeredPane_11.add(pnlTbl10E);
			
			btnNewButton_18 = new JButton("Empty");
			btnNewButton_18.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table10(pnlTbl10F);
				}
			});
			pnlTbl10E.add(btnNewButton_18);
			
			pnlTbl10F = new JPanel();
			pnlTbl10F.setBackground(Color.RED);
			pnlTbl10F.setBounds(0, 0, 76, 61);
			layeredPane_11.add(pnlTbl10F);
			
			btnNewButton_19 = new JButton("Full");
			btnNewButton_19.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table10(pnlTbl10E);
				}
			});
			pnlTbl10F.add(btnNewButton_19);
			
			layeredPane_12 = new JLayeredPane();
			layeredPane_12.setBounds(57, 336, 76, 61);
			pnlTables.add(layeredPane_12);
			
			pnlTbl11E = new JPanel();
			pnlTbl11E.setBackground(Color.GREEN);
			pnlTbl11E.setBounds(0, 0, 76, 61);
			layeredPane_12.add(pnlTbl11E);
			
			btnNewButton_20 = new JButton("Empty");
			btnNewButton_20.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table11(pnlTbl11F);
				}
			});
			pnlTbl11E.add(btnNewButton_20);
			
			pnlTbl11F = new JPanel();
			pnlTbl11F.setBackground(Color.RED);
			pnlTbl11F.setBounds(0, 0, 76, 61);
			layeredPane_12.add(pnlTbl11F);
			
			btnNewButton_21 = new JButton("Full");
			btnNewButton_21.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table11(pnlTbl11E);
				}
			});
			pnlTbl11F.add(btnNewButton_21);
			
			layeredPane_13 = new JLayeredPane();
			layeredPane_13.setBounds(200, 336, 76, 61);
			pnlTables.add(layeredPane_13);
			
			pnlTbl12E = new JPanel();
			pnlTbl12E.setBackground(Color.GREEN);
			pnlTbl12E.setBounds(0, 0, 76, 61);
			layeredPane_13.add(pnlTbl12E);
			
			btnNewButton_22 = new JButton("Empty");
			btnNewButton_22.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table12(pnlTbl12F);
				}
			});
			pnlTbl12E.add(btnNewButton_22);
			
			pnlTbl12F = new JPanel();
			pnlTbl12F.setBackground(Color.RED);
			pnlTbl12F.setBounds(0, 0, 76, 61);
			layeredPane_13.add(pnlTbl12F);
			
			btnNewButton_23 = new JButton("Full");
			btnNewButton_23.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table12(pnlTbl12E);
				}
			});
			pnlTbl12F.add(btnNewButton_23);
			
			layeredPane_14 = new JLayeredPane();
			layeredPane_14.setBounds(350, 336, 76, 61);
			pnlTables.add(layeredPane_14);
			
			pnlTbl13E = new JPanel();
			pnlTbl13E.setBackground(Color.GREEN);
			pnlTbl13E.setBounds(0, 0, 76, 61);
			layeredPane_14.add(pnlTbl13E);
			
			btnNewButton_24 = new JButton("Empty");
			btnNewButton_24.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table13(pnlTbl13F);
				}
			});
			pnlTbl13E.add(btnNewButton_24);
			
			pnlTbl13F = new JPanel();
			pnlTbl13F.setBackground(Color.RED);
			pnlTbl13F.setBounds(0, 0, 76, 61);
			layeredPane_14.add(pnlTbl13F);
			
			btnNewButton_25 = new JButton("Full");
			btnNewButton_25.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table13(pnlTbl13E);
				}
			});
			pnlTbl13F.add(btnNewButton_25);
			
			layeredPane_15 = new JLayeredPane();
			layeredPane_15.setBounds(490, 336, 76, 61);
			pnlTables.add(layeredPane_15);
			
			pnlTbl14E = new JPanel();
			pnlTbl14E.setBackground(Color.GREEN);
			pnlTbl14E.setBounds(0, 0, 76, 61);
			layeredPane_15.add(pnlTbl14E);
			
			btnNewButton_26 = new JButton("Empty");
			btnNewButton_26.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table14(pnlTbl14F);
				}
			});
			pnlTbl14E.add(btnNewButton_26);
			
			pnlTbl14F = new JPanel();
			pnlTbl14F.setBackground(Color.RED);
			pnlTbl14F.setBounds(0, 0, 76, 61);
			layeredPane_15.add(pnlTbl14F);
			
			btnNewButton_27 = new JButton("Full");
			btnNewButton_27.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table14(pnlTbl14E);
				}
			});
			pnlTbl14F.add(btnNewButton_27);
			
			layeredPane_16 = new JLayeredPane();
			layeredPane_16.setBounds(635, 336, 76, 61);
			pnlTables.add(layeredPane_16);
			
			pnlTbl15E = new JPanel();
			pnlTbl15E.setBackground(Color.GREEN);
			pnlTbl15E.setBounds(0, 0, 76, 61);
			layeredPane_16.add(pnlTbl15E);
			
			btnNewButton_28 = new JButton("Empty");
			btnNewButton_28.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table15(pnlTbl15F);
				}
			});
			pnlTbl15E.add(btnNewButton_28);
			
			pnlTbl15F = new JPanel();
			pnlTbl15F.setBackground(Color.RED);
			pnlTbl15F.setBounds(0, 0, 76, 61);
			layeredPane_16.add(pnlTbl15F);
			
			btnNewButton_29 = new JButton("Full");
			btnNewButton_29.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Switch_table15(pnlTbl15E);
				}
			});
			pnlTbl15F.add(btnNewButton_29);
			
			lblNewLabel_5 = new JLabel("Table 6");
			lblNewLabel_5.setForeground(new Color(255, 250, 205));
			lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 18));
			lblNewLabel_5.setBounds(67, 190, 76, 14);
			pnlTables.add(lblNewLabel_5);
			
			lblNewLabel_4_5 = new JLabel("Table 7");
			lblNewLabel_4_5.setForeground(new Color(255, 250, 205));
			lblNewLabel_4_5.setFont(new Font("Times New Roman", Font.BOLD, 18));
			lblNewLabel_4_5.setBounds(210, 190, 76, 14);
			pnlTables.add(lblNewLabel_4_5);
			
			lblNewLabel_4_6 = new JLabel("Table 8");
			lblNewLabel_4_6.setForeground(new Color(255, 250, 205));
			lblNewLabel_4_6.setFont(new Font("Times New Roman", Font.BOLD, 18));
			lblNewLabel_4_6.setBounds(362, 190, 76, 14);
			pnlTables.add(lblNewLabel_4_6);
			
			lblNewLabel_4_7 = new JLabel("Table 9");
			lblNewLabel_4_7.setForeground(new Color(255, 250, 205));
			lblNewLabel_4_7.setFont(new Font("Times New Roman", Font.BOLD, 18));
			lblNewLabel_4_7.setBounds(500, 190, 76, 14);
			pnlTables.add(lblNewLabel_4_7);
			
			lblNewLabel_4_8 = new JLabel("Table 10");
			lblNewLabel_4_8.setForeground(new Color(255, 250, 205));
			lblNewLabel_4_8.setFont(new Font("Times New Roman", Font.BOLD, 18));
			lblNewLabel_4_8.setBounds(639, 190, 76, 14);
			pnlTables.add(lblNewLabel_4_8);
			
			lblNewLabel_6 = new JLabel("Table 11");
			lblNewLabel_6.setForeground(new Color(255, 250, 205));
			lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 18));
			lblNewLabel_6.setBounds(62, 319, 76, 14);
			pnlTables.add(lblNewLabel_6);
			
			lblNewLabel_4_9 = new JLabel("Table 12");
			lblNewLabel_4_9.setForeground(new Color(255, 250, 205));
			lblNewLabel_4_9.setFont(new Font("Times New Roman", Font.BOLD, 18));
			lblNewLabel_4_9.setBounds(205, 319, 76, 14);
			pnlTables.add(lblNewLabel_4_9);
			
			lblNewLabel_4_10 = new JLabel("Table 13");
			lblNewLabel_4_10.setForeground(new Color(255, 250, 205));
			lblNewLabel_4_10.setFont(new Font("Times New Roman", Font.BOLD, 18));
			lblNewLabel_4_10.setBounds(355, 319, 76, 14);
			pnlTables.add(lblNewLabel_4_10);
			
			lblNewLabel_4_11 = new JLabel("Table 14");
			lblNewLabel_4_11.setForeground(new Color(255, 250, 205));
			lblNewLabel_4_11.setFont(new Font("Times New Roman", Font.BOLD, 18));
			lblNewLabel_4_11.setBounds(495, 319, 76, 14);
			pnlTables.add(lblNewLabel_4_11);
			
			lblNewLabel_4_12 = new JLabel("Table 15");
			lblNewLabel_4_12.setForeground(new Color(255, 250, 205));
			lblNewLabel_4_12.setFont(new Font("Times New Roman", Font.BOLD, 18));
			lblNewLabel_4_12.setBounds(639, 319, 76, 14);
			pnlTables.add(lblNewLabel_4_12);
			
				pnlTickets = new JPanel();
				pnlTickets.setBackground(Color.GRAY);
				pnlTickets.setBounds(0, 0, 794, 460);
				layeredPane.add(pnlTickets);
				pnlTickets.setLayout(null);
				
					btnHome_3 = new JButton("Home");
					btnHome_3.setForeground(new Color(153, 0, 51));
					btnHome_3.setBackground(new Color(255, 255, 204));
					btnHome_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnHome_3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
					Switch_Screen(pnlHome);
					}
					});
					btnHome_3.setBounds(696, 11, 88, 31);
					pnlTickets.add(btnHome_3);
					
					JLabel lblNewLabel_2_1 = new JLabel("Ticket");
					lblNewLabel_2_1.setForeground(new Color(255, 255, 204));
					lblNewLabel_2_1.setFont(new Font("Lucida Handwriting", Font.BOLD, 32));
					lblNewLabel_2_1.setBounds(331, 11, 129, 48);
					pnlTickets.add(lblNewLabel_2_1);
					
					JButton btnNewButton_30 = new JButton("Create");
					btnNewButton_30.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							Switch_tiketPage(pnlCreTkt);
						}
					});
					btnNewButton_30.setBackground(new Color(250, 250, 210));
					btnNewButton_30.setForeground(new Color(139, 0, 0));
					btnNewButton_30.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnNewButton_30.setBounds(178, 56, 100, 31);
					pnlTickets.add(btnNewButton_30);
					
					JButton btnNewButton_30_1 = new JButton("Active");
					btnNewButton_30_1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							Switch_tiketPage(pnlActTkt);
						}
					});
					btnNewButton_30_1.setForeground(new Color(139, 0, 0));
					btnNewButton_30_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnNewButton_30_1.setBackground(new Color(250, 250, 210));
					btnNewButton_30_1.setBounds(338, 56, 100, 31);
					pnlTickets.add(btnNewButton_30_1);
					
					JButton btnNewButton_30_2 = new JButton("Closed");
					btnNewButton_30_2.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							Switch_tiketPage(pnlCldTkt);
						}
					});
					btnNewButton_30_2.setForeground(new Color(139, 0, 0));
					btnNewButton_30_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnNewButton_30_2.setBackground(new Color(250, 250, 210));
					btnNewButton_30_2.setBounds(498, 56, 100, 31);
					pnlTickets.add(btnNewButton_30_2);
					
					layeredPaneTkt = new JLayeredPane();
					layeredPaneTkt.setBounds(10, 98, 774, 351);
					pnlTickets.add(layeredPaneTkt);
					
					pnlActTkt = new JPanel();
					pnlActTkt.setBackground(Color.GRAY);
					pnlActTkt.setBounds(0, 0, 774, 351);
					layeredPaneTkt.add(pnlActTkt);
					pnlActTkt.setLayout(null);
					
					lblTicket = new JLabel("Ticket Num:");
					lblTicket.setForeground(new Color(255, 255, 204));
					lblTicket.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblTicket.setBounds(144, 39, 122, 43);
					pnlActTkt.add(lblTicket);
					
					lblTableNum = new JLabel("Table Num:");
					lblTableNum.setForeground(new Color(255, 255, 204));
					lblTableNum.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblTableNum.setBounds(144, 109, 122, 43);
					pnlActTkt.add(lblTableNum);
					
					lblOrderId = new JLabel("Order:");
					lblOrderId.setForeground(new Color(255, 255, 204));
					lblOrderId.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblOrderId.setBounds(144, 249, 122, 43);
					pnlActTkt.add(lblOrderId);
					
					lblTicketTotal = new JLabel("Ticket Total:");
					lblTicketTotal.setForeground(new Color(255, 255, 204));
					lblTicketTotal.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblTicketTotal.setBounds(144, 179, 122, 43);
					pnlActTkt.add(lblTicketTotal);
					
					textField = new JTextField();
					textField.setBounds(357, 39, 249, 43);
					pnlActTkt.add(textField);
					textField.setColumns(10);
					
					textField_5 = new JTextField();
					textField_5.setColumns(10);
					textField_5.setBounds(357, 109, 249, 43);
					pnlActTkt.add(textField_5);
					
					textField_6 = new JTextField();
					textField_6.setColumns(10);
					textField_6.setBounds(357, 179, 249, 43);
					pnlActTkt.add(textField_6);
					
					btnNewButton_31 = new JButton("View Order");
					btnNewButton_31.addActionListener(new ActionListener() {
						

						public void actionPerformed(ActionEvent e) {
							Switch_tiketPage(pnlVewOrd);
						}
					});
					btnNewButton_31.setForeground(new Color(178, 34, 34));
					btnNewButton_31.setBackground(new Color(250, 250, 210));
					btnNewButton_31.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnNewButton_31.setBounds(357, 249, 131, 43);
					pnlActTkt.add(btnNewButton_31);
					
					btnNewButton_32 = new JButton("Next Ticket");
					btnNewButton_32.setBackground(new Color(250, 250, 210));
					btnNewButton_32.setForeground(new Color(178, 34, 34));
					btnNewButton_32.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnNewButton_32.setBounds(634, 303, 140, 37);
					pnlActTkt.add(btnNewButton_32);
					
					btnNewButton_33 = new JButton("Previous Ticket");
					btnNewButton_33.setForeground(new Color(178, 34, 34));
					btnNewButton_33.setBackground(new Color(250, 250, 210));
					btnNewButton_33.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnNewButton_33.setBounds(10, 303, 140, 37);
					pnlActTkt.add(btnNewButton_33);
					
					lblActive = new JLabel("Active");
					lblActive.setForeground(new Color(255, 255, 204));
					lblActive.setFont(new Font("Tahoma", Font.BOLD, 22));
					lblActive.setBounds(0, 0, 70, 37);
					pnlActTkt.add(lblActive);
					
					pnlCreTkt = new JPanel();
					pnlCreTkt.setBackground(Color.GRAY);
					pnlCreTkt.setBounds(0, 0, 774, 351);
					layeredPaneTkt.add(pnlCreTkt);
					pnlCreTkt.setLayout(null);
					
					lblTicket = new JLabel("Ticket Num:");
					lblTicket.setForeground(new Color(255, 255, 204));
					lblTicket.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblTicket.setBounds(144, 39, 122, 43);
					pnlCreTkt.add(lblTicket);
					
					lblTableNum = new JLabel("Table Num:");
					lblTableNum.setForeground(new Color(255, 255, 204));
					lblTableNum.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblTableNum.setBounds(144, 109, 122, 43);
					pnlCreTkt.add(lblTableNum);
					
					lblOrderId = new JLabel("Order:");
					lblOrderId.setForeground(new Color(255, 255, 204));
					lblOrderId.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblOrderId.setBounds(144, 249, 122, 43);
					pnlCreTkt.add(lblOrderId);
					
					lblTicketTotal = new JLabel("Ticket Total:");
					lblTicketTotal.setForeground(new Color(255, 255, 204));
					lblTicketTotal.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblTicketTotal.setBounds(144, 179, 122, 43);
					pnlCreTkt.add(lblTicketTotal);
					
					textField = new JTextField();
					textField.setBounds(357, 39, 249, 43);
					pnlCreTkt.add(textField);
					textField.setColumns(10);
					
					textField_7 = new JTextField();
					textField_7.setColumns(10);
					textField_7.setBounds(357, 109, 249, 43);
					pnlCreTkt.add(textField_7);
					
					textField_8 = new JTextField();
					textField_8.setColumns(10);
					textField_8.setBounds(357, 179, 249, 43);
					pnlCreTkt.add(textField_8);
					
					btnNewButton_34 = new JButton("Create Order");
					btnNewButton_34.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							Switch_tiketPage(pnlCrtOrd);
						}
					});
					btnNewButton_34.setForeground(new Color(178, 34, 34));
					btnNewButton_34.setBackground(new Color(250, 250, 210));
					btnNewButton_34.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnNewButton_34.setBounds(357, 249, 131, 43);
					pnlCreTkt.add(btnNewButton_34);
					
					lblActive = new JLabel("Create");
					lblActive.setForeground(new Color(255, 255, 204));
					lblActive.setFont(new Font("Tahoma", Font.BOLD, 22));
					lblActive.setBounds(0, 0, 83, 37);
					pnlCreTkt.add(lblActive);
					
					pnlCldTkt = new JPanel();
					pnlCldTkt.setBackground(Color.GRAY);
					pnlCldTkt.setBounds(0, 0, 774, 351);
					layeredPaneTkt.add(pnlCldTkt);
					pnlCldTkt.setLayout(null);
					
					lblTicket = new JLabel("Ticket Num:");
					lblTicket.setForeground(new Color(255, 255, 204));
					lblTicket.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblTicket.setBounds(144, 39, 122, 43);
					pnlCldTkt.add(lblTicket);
					
					lblTableNum = new JLabel("Table Num:");
					lblTableNum.setForeground(new Color(255, 255, 204));
					lblTableNum.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblTableNum.setBounds(144, 109, 122, 43);
					pnlCldTkt.add(lblTableNum);
					
					lblOrderId = new JLabel("Order:");
					lblOrderId.setForeground(new Color(255, 255, 204));
					lblOrderId.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblOrderId.setBounds(144, 249, 122, 43);
					pnlCldTkt.add(lblOrderId);
					
					lblTicketTotal = new JLabel("Ticket Total:");
					lblTicketTotal.setForeground(new Color(255, 255, 204));
					lblTicketTotal.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblTicketTotal.setBounds(144, 179, 122, 43);
					pnlCldTkt.add(lblTicketTotal);
					
					textField = new JTextField();
					textField.setBounds(357, 39, 249, 43);
					pnlCldTkt.add(textField);
					textField.setColumns(10);
					
					textField_5 = new JTextField();
					textField_5.setColumns(10);
					textField_5.setBounds(357, 109, 249, 43);
					pnlCldTkt.add(textField_5);
					
					textField_6 = new JTextField();
					textField_6.setColumns(10);
					textField_6.setBounds(357, 179, 249, 43);
					pnlCldTkt.add(textField_6);
					
					btnNewButton_31 = new JButton("View Order");
					btnNewButton_31.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							Switch_tiketPage(pnlVewOrd);
						}
					});
					btnNewButton_31.setForeground(new Color(178, 34, 34));
					btnNewButton_31.setBackground(new Color(250, 250, 210));
					btnNewButton_31.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnNewButton_31.setBounds(357, 249, 131, 43);
					pnlCldTkt.add(btnNewButton_31);
					
					btnNewButton_32 = new JButton("Next Ticket");
					btnNewButton_32.setBackground(new Color(250, 250, 210));
					btnNewButton_32.setForeground(new Color(178, 34, 34));
					btnNewButton_32.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnNewButton_32.setBounds(634, 303, 140, 37);
					pnlCldTkt.add(btnNewButton_32);
					
					btnNewButton_33 = new JButton("Previous Ticket");
					btnNewButton_33.setForeground(new Color(178, 34, 34));
					btnNewButton_33.setBackground(new Color(250, 250, 210));
					btnNewButton_33.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnNewButton_33.setBounds(10, 303, 140, 37);
					pnlCldTkt.add(btnNewButton_33);
					
					lblActive = new JLabel("Clsoed");
					lblActive.setForeground(new Color(255, 255, 204));
					lblActive.setFont(new Font("Tahoma", Font.BOLD, 22));
					lblActive.setBounds(0, 0, 94, 37);
					pnlCldTkt.add(lblActive);
					
					pnlCrtOrd = new JPanel();
					pnlCrtOrd.setBackground(Color.GRAY);
					pnlCrtOrd.setBounds(0, 0, 774, 351);
					layeredPaneTkt.add(pnlCrtOrd);
					pnlCrtOrd.setLayout(null);
					
					lblOrderId_1 = new JLabel("Order ID:");
					lblOrderId_1.setForeground(new Color(255, 255, 204));
					lblOrderId_1.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblOrderId_1.setBounds(144, 39, 122, 43);
					pnlCrtOrd.add(lblOrderId_1);
					
					lblFoodId_1 = new JLabel("Food ID:");
					lblFoodId_1.setForeground(new Color(255, 255, 204));
					lblFoodId_1.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblFoodId_1.setBounds(144, 109, 122, 43);
					pnlCrtOrd.add(lblFoodId_1);
					
					lblDrinkId_1 = new JLabel("Drink ID:");
					lblDrinkId_1.setForeground(new Color(255, 255, 204));
					lblDrinkId_1.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblDrinkId_1.setBounds(144, 179, 122, 43);
					pnlCrtOrd.add(lblDrinkId_1);
					
					textField_13 = new JTextField();
					textField_13.setColumns(10);
					textField_13.setBounds(357, 39, 249, 43);
					pnlCrtOrd.add(textField_13);
					
					textField_14 = new JTextField();
					textField_14.setColumns(10);
					textField_14.setBounds(357, 109, 249, 43);
					pnlCrtOrd.add(textField_14);
					
					textField_15 = new JTextField();
					textField_15.setColumns(10);
					textField_15.setBounds(357, 179, 249, 43);
					pnlCrtOrd.add(textField_15);
					
					lblCreateOrder = new JLabel("Create Order");
					lblCreateOrder.setForeground(new Color(255, 255, 204));
					lblCreateOrder.setFont(new Font("Tahoma", Font.BOLD, 22));
					lblCreateOrder.setBounds(0, 0, 143, 37);
					pnlCrtOrd.add(lblCreateOrder);
					
					btnNewButton_35 = new JButton("Save Order");
					btnNewButton_35.setForeground(new Color(178, 34, 34));
					btnNewButton_35.setFont(new Font("Times New Roman", Font.BOLD, 14));
					btnNewButton_35.setBackground(new Color(250, 250, 210));
					btnNewButton_35.setBounds(633, 297, 131, 43);
					pnlCrtOrd.add(btnNewButton_35);
					
					pnlVewOrd = new JPanel();
					pnlVewOrd.setBackground(Color.GRAY);
					pnlVewOrd.setBounds(0, 0, 774, 351);
					layeredPaneTkt.add(pnlVewOrd);
					pnlVewOrd.setLayout(null);
					
					JLabel lblOrderId_2 = new JLabel("Order ID:");
					lblOrderId_2.setForeground(new Color(255, 255, 204));
					lblOrderId_2.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblOrderId_2.setBounds(144, 39, 122, 43);
					pnlVewOrd.add(lblOrderId_2);
					
					JLabel lblFoodId = new JLabel("Food ID:");
					lblFoodId.setForeground(new Color(255, 255, 204));
					lblFoodId.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblFoodId.setBounds(144, 109, 122, 43);
					pnlVewOrd.add(lblFoodId);
					
					JLabel lblDrinkId = new JLabel("Drink ID:");
					lblDrinkId.setForeground(new Color(255, 255, 204));
					lblDrinkId.setFont(new Font("Tahoma", Font.BOLD, 18));
					lblDrinkId.setBounds(144, 179, 122, 43);
					pnlVewOrd.add(lblDrinkId);
					
					textField_10 = new JTextField();
					textField_10.setColumns(10);
					textField_10.setBounds(357, 39, 249, 43);
					pnlVewOrd.add(textField_10);
					
					textField_11 = new JTextField();
					textField_11.setColumns(10);
					textField_11.setBounds(357, 109, 249, 43);
					pnlVewOrd.add(textField_11);
					
					textField_12 = new JTextField();
					textField_12.setColumns(10);
					textField_12.setBounds(357, 179, 249, 43);
					pnlVewOrd.add(textField_12);
					
					JLabel lblViewOrder = new JLabel("View Order");
					lblViewOrder.setForeground(new Color(255, 255, 204));
					lblViewOrder.setFont(new Font("Tahoma", Font.BOLD, 22));
					lblViewOrder.setBounds(0, 0, 130, 37);
					pnlVewOrd.add(lblViewOrder);
	}

	public void Switch_Screen(JPanel p) {
		layeredPane.removeAll();
		layeredPane.add(p);
		layeredPane.repaint();
		layeredPane.revalidate();
	}
	public void Switch_table1(JPanel p) {
		layeredPane_2.removeAll();
		layeredPane_2.add(p);
		layeredPane_2.repaint();
		layeredPane_2.revalidate();
	}
	public void Switch_table2(JPanel p) {
		layeredPane_3.removeAll();
		layeredPane_3.add(p);
		layeredPane_3.repaint();
		layeredPane_3.revalidate();
	}
	public void Switch_table3(JPanel p) {
		layeredPane_4.removeAll();
		layeredPane_4.add(p);
		layeredPane_4.repaint();
		layeredPane_4.revalidate();
	}
	public void Switch_table4(JPanel p) {
		layeredPane_5.removeAll();
		layeredPane_5.add(p);
		layeredPane_5.repaint();
		layeredPane_5.revalidate();
	}
	public void Switch_table5(JPanel p) {
		layeredPane_6.removeAll();
		layeredPane_6.add(p);
		layeredPane_6.repaint();
		layeredPane_6.revalidate();
	}
	public void Switch_table6(JPanel p) {
		layeredPane_7.removeAll();
		layeredPane_7.add(p);
		layeredPane_7.repaint();
		layeredPane_7.revalidate();
	}
	public void Switch_table7(JPanel p) {
		layeredPane_8.removeAll();
		layeredPane_8.add(p);
		layeredPane_8.repaint();
		layeredPane_8.revalidate();
	}
	public void Switch_table8(JPanel p) {
		layeredPane_9.removeAll();
		layeredPane_9.add(p);
		layeredPane_9.repaint();
		layeredPane_9.revalidate();
	}
	public void Switch_table9(JPanel p) {
		layeredPane_10.removeAll();
		layeredPane_10.add(p);
		layeredPane_10.repaint();
		layeredPane_10.revalidate();
	}
	public void Switch_table10(JPanel p) {
		layeredPane_11.removeAll();
		layeredPane_11.add(p);
		layeredPane_11.repaint();
		layeredPane_11.revalidate();
	}
	public void Switch_table11(JPanel p) {
		layeredPane_12.removeAll();
		layeredPane_12.add(p);
		layeredPane_12.repaint();
		layeredPane_12.revalidate();
	}
	public void Switch_table12(JPanel p) {
		layeredPane_13.removeAll();
		layeredPane_13.add(p);
		layeredPane_13.repaint();
		layeredPane_13.revalidate();
	}
	public void Switch_table13(JPanel p) {
		layeredPane_14.removeAll();
		layeredPane_14.add(p);
		layeredPane_14.repaint();
		layeredPane_14.revalidate();
	}
	public void Switch_table14(JPanel p) {
		layeredPane_15.removeAll();
		layeredPane_15.add(p);
		layeredPane_15.repaint();
		layeredPane_15.revalidate();
	}
	public void Switch_table15(JPanel p) {
		layeredPane_16.removeAll();
		layeredPane_16.add(p);
		layeredPane_16.repaint();
		layeredPane_16.revalidate();
	}
	public void Switch_tiketPage(JPanel p) {
		layeredPaneTkt.removeAll();
		layeredPaneTkt.add(p);
		layeredPaneTkt.repaint();
		layeredPaneTkt.revalidate();
	}
	}